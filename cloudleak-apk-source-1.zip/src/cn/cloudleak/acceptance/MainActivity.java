package cn.cloudleak.acceptance;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
public final class MainActivity extends Activity {
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    TextView text = new TextView(this);
    text.setText("CloudLeak APK collection acceptance\nOwn-source inert sample\nNo credentials. No network permissions.");
    text.setTextSize(22); text.setPadding(32, 64, 32, 32); setContentView(text);
  }
}
