App({
  globalData: {
    acceptanceMarker: 'CLOUDLEAK-MINIPROGRAM-CONNECTIVITY-20261013',
    version: '0.1.0'
  }
});
