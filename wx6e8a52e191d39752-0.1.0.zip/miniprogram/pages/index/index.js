Page({
  data: {
    appid: 'wx6e8a52e191d39752',
    version: '0.1.0',
    status: '等待本地检查'
  },
  checkLocal() {
    this.setData({ status: '页面运行正常；未发送网络请求' });
  }
});
